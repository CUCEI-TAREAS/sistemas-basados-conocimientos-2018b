/*
* M�dulo Principal Porci�n Dise�o
* 
* Encargado de la confecci�n de la interfaz gr�fica de usuario, y de la
* interpretaci�n de los eventos causantes de la conversi�n de una regla
* del tipo SI-ENTONCES modelada a trav�s de la interfaz gr�fica de esta
* aplicaci�n, en una representaci�n del tipo LM-Regla. 
* 
* El lenguaje LM-Regla es un producto de la investigaci�n para representar
* y gestionar conocimiento �til en la construcci�n de Sistemas Expertos.
* Investigaci�n que ha provocado el desarrollo de esta aplicaci�n, la cual 
* contiene los algoritmos para interpretar una representaci�n visual de una
* regla SI-ENTONCES (convencional y cl�sica) a una representaci�n del tipo
* LM-Regla que es congruente con los est�ndares actuales de representaci�n
* de conocimiento.
*
* Desarrollador: Luis Alberto Casillas Santill�n
* Fecha: 11/08/2006
* 
*/
 
using System.IO;

namespace LM_Regla{
	partial class MainForm : System.Windows.Forms.Form{
		bool negadoConc=false,objetivo=false;
		
		private System.ComponentModel.IContainer components = null;
		
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.button12 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.button13 = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.button8 = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.listBox3 = new System.Windows.Forms.ListBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.button14 = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.button10 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.label6 = new System.Windows.Forms.Label();
			this.button11 = new System.Windows.Forms.Button();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Controls.Add(this.tabPage5);
			this.tabControl1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
			this.tabControl1.Location = new System.Drawing.Point(12, 12);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(439, 317);
			this.tabControl1.TabIndex = 0;
			this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.TabControl1Selected);
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.Color.Turquoise;
			this.tabPage1.Controls.Add(this.button12);
			this.tabPage1.Controls.Add(this.button7);
			this.tabPage1.Controls.Add(this.button1);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.listBox1);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(431, 291);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Atomos";
			// 
			// button12
			// 
			this.button12.Location = new System.Drawing.Point(6, 203);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(204, 62);
			this.button12.TabIndex = 3;
			this.button12.Text = "&Cargar atomos";
			this.button12.UseVisualStyleBackColor = true;
			this.button12.Click += new System.EventHandler(this.Button12Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(6, 135);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(204, 62);
			this.button7.TabIndex = 2;
			this.button7.Text = "&Eliminar atomo";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.Button7Click);
			// 
			// button1
			// 
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.Location = new System.Drawing.Point(6, 68);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(204, 61);
			this.button1.TabIndex = 1;
			this.button1.Text = "&Agregar atomo";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(216, 15);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(212, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Registro de atomos";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(6, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(204, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Ingresar atomo";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// listBox1
			// 
			this.listBox1.BackColor = System.Drawing.Color.Gainsboro;
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Location = new System.Drawing.Point(216, 41);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(212, 225);
			this.listBox1.TabIndex = 4;
			// 
			// textBox1
			// 
			this.textBox1.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox1.Location = new System.Drawing.Point(6, 41);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(204, 21);
			this.textBox1.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.BackColor = System.Drawing.Color.Turquoise;
			this.tabPage2.Controls.Add(this.button13);
			this.tabPage2.Controls.Add(this.textBox3);
			this.tabPage2.Controls.Add(this.checkBox1);
			this.tabPage2.Controls.Add(this.button8);
			this.tabPage2.Controls.Add(this.label4);
			this.tabPage2.Controls.Add(this.button6);
			this.tabPage2.Controls.Add(this.button5);
			this.tabPage2.Controls.Add(this.button4);
			this.tabPage2.Controls.Add(this.button3);
			this.tabPage2.Controls.Add(this.button2);
			this.tabPage2.Controls.Add(this.label3);
			this.tabPage2.Controls.Add(this.listBox3);
			this.tabPage2.Controls.Add(this.textBox2);
			this.tabPage2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(431, 291);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Condicion";
			// 
			// button13
			// 
			this.button13.Location = new System.Drawing.Point(397, 15);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(28, 21);
			this.button13.TabIndex = 10;
			this.button13.Text = "R";
			this.button13.UseVisualStyleBackColor = true;
			this.button13.Click += new System.EventHandler(this.Button13Click);
			// 
			// textBox3
			// 
			this.textBox3.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.textBox3.Location = new System.Drawing.Point(133, 262);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(292, 21);
			this.textBox3.TabIndex = 9;
			// 
			// checkBox1
			// 
			this.checkBox1.Location = new System.Drawing.Point(134, 70);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(74, 35);
			this.checkBox1.TabIndex = 6;
			this.checkBox1.Text = "Negado";
			this.checkBox1.UseVisualStyleBackColor = true;
			this.checkBox1.CheckedChanged += new System.EventHandler(this.CheckBox1CheckedChanged);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(21, 262);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(106, 21);
			this.button8.TabIndex = 8;
			this.button8.Text = "Polaca";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.Button8Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(21, 48);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(187, 23);
			this.label4.TabIndex = 7;
			this.label4.Text = "Operaciones";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button6
			// 
			this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button6.Location = new System.Drawing.Point(133, 111);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(75, 145);
			this.button6.TabIndex = 7;
			this.button6.Text = "Usar atomo";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.Button6Click);
			// 
			// button5
			// 
			this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button5.Location = new System.Drawing.Point(77, 166);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(50, 90);
			this.button5.TabIndex = 4;
			this.button5.Text = ")";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.Button5Click);
			// 
			// button4
			// 
			this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button4.Location = new System.Drawing.Point(21, 166);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(50, 90);
			this.button4.TabIndex = 3;
			this.button4.Text = "(";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.Button4Click);
			// 
			// button3
			// 
			this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button3.Location = new System.Drawing.Point(77, 70);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(50, 90);
			this.button3.TabIndex = 2;
			this.button3.Text = "O";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.Button3Click);
			// 
			// button2
			// 
			this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button2.Location = new System.Drawing.Point(21, 70);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(50, 90);
			this.button2.TabIndex = 1;
			this.button2.Text = "Y";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(213, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(212, 23);
			this.label3.TabIndex = 8;
			this.label3.Text = "Registro de atomos";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// listBox3
			// 
			this.listBox3.BackColor = System.Drawing.Color.Gainsboro;
			this.listBox3.FormattingEnabled = true;
			this.listBox3.Location = new System.Drawing.Point(213, 70);
			this.listBox3.Name = "listBox3";
			this.listBox3.Size = new System.Drawing.Size(212, 186);
			this.listBox3.Sorted = true;
			this.listBox3.TabIndex = 5;
			// 
			// textBox2
			// 
			this.textBox2.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox2.Location = new System.Drawing.Point(6, 15);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(385, 21);
			this.textBox2.TabIndex = 0;
			// 
			// tabPage3
			// 
			this.tabPage3.BackColor = System.Drawing.Color.Turquoise;
			this.tabPage3.Controls.Add(this.checkBox3);
			this.tabPage3.Controls.Add(this.button14);
			this.tabPage3.Controls.Add(this.label5);
			this.tabPage3.Controls.Add(this.textBox5);
			this.tabPage3.Controls.Add(this.button10);
			this.tabPage3.Controls.Add(this.button9);
			this.tabPage3.Controls.Add(this.listBox2);
			this.tabPage3.Controls.Add(this.checkBox2);
			this.tabPage3.Controls.Add(this.textBox4);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(431, 291);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Conclusion";
			// 
			// checkBox3
			// 
			this.checkBox3.Location = new System.Drawing.Point(16, 77);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(75, 28);
			this.checkBox3.TabIndex = 12;
			this.checkBox3.Text = "Objetivo";
			this.checkBox3.UseVisualStyleBackColor = true;
			this.checkBox3.CheckedChanged += new System.EventHandler(this.CheckBox3CheckedChanged);
			// 
			// button14
			// 
			this.button14.Location = new System.Drawing.Point(387, 16);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(28, 21);
			this.button14.TabIndex = 11;
			this.button14.Text = "R";
			this.button14.UseVisualStyleBackColor = true;
			this.button14.Click += new System.EventHandler(this.Button14Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(157, 55);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(259, 23);
			this.label5.TabIndex = 6;
			this.label5.Text = "Registro de atomos";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox5
			// 
			this.textBox5.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox5.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.textBox5.Location = new System.Drawing.Point(97, 260);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(319, 21);
			this.textBox5.TabIndex = 5;
			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(16, 260);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(75, 23);
			this.button10.TabIndex = 4;
			this.button10.Text = "Polaca:";
			this.button10.UseVisualStyleBackColor = true;
			this.button10.Click += new System.EventHandler(this.Button10Click);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(16, 111);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(135, 143);
			this.button9.TabIndex = 3;
			this.button9.Text = "Agrega";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.Button9Click);
			// 
			// listBox2
			// 
			this.listBox2.BackColor = System.Drawing.Color.Gainsboro;
			this.listBox2.FormattingEnabled = true;
			this.listBox2.Location = new System.Drawing.Point(157, 81);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(258, 173);
			this.listBox2.Sorted = true;
			this.listBox2.TabIndex = 2;
			// 
			// checkBox2
			// 
			this.checkBox2.Location = new System.Drawing.Point(16, 43);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(71, 28);
			this.checkBox2.TabIndex = 1;
			this.checkBox2.Text = "Negado";
			this.checkBox2.UseVisualStyleBackColor = true;
			this.checkBox2.CheckedChanged += new System.EventHandler(this.CheckBox2CheckedChanged);
			// 
			// textBox4
			// 
			this.textBox4.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox4.Location = new System.Drawing.Point(16, 16);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(365, 21);
			this.textBox4.TabIndex = 0;
			// 
			// tabPage4
			// 
			this.tabPage4.BackColor = System.Drawing.Color.Turquoise;
			this.tabPage4.Controls.Add(this.label6);
			this.tabPage4.Controls.Add(this.button11);
			this.tabPage4.Controls.Add(this.textBox6);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(431, 291);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Regla";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(73, 7);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(355, 23);
			this.label6.TabIndex = 2;
			this.label6.Text = "LM Regla";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button11
			// 
			this.button11.Location = new System.Drawing.Point(3, 3);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(64, 285);
			this.button11.TabIndex = 1;
			this.button11.Text = "Generar";
			this.button11.UseVisualStyleBackColor = true;
			this.button11.Click += new System.EventHandler(this.Button11Click);
			// 
			// textBox6
			// 
			this.textBox6.BackColor = System.Drawing.Color.Gainsboro;
			this.textBox6.Location = new System.Drawing.Point(73, 33);
			this.textBox6.Multiline = true;
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(355, 255);
			this.textBox6.TabIndex = 0;
			// 
			// tabPage5
			// 
			this.tabPage5.BackColor = System.Drawing.Color.Turquoise;
			this.tabPage5.Controls.Add(this.textBox7);
			this.tabPage5.Controls.Add(this.label7);
			this.tabPage5.Location = new System.Drawing.Point(4, 22);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Size = new System.Drawing.Size(431, 291);
			this.tabPage5.TabIndex = 4;
			this.tabPage5.Text = "Acerca...";
			// 
			// textBox7
			// 
			this.textBox7.BackColor = System.Drawing.Color.MistyRose;
			this.textBox7.Cursor = System.Windows.Forms.Cursors.UpArrow;
			this.textBox7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
			this.textBox7.Location = new System.Drawing.Point(29, 64);
			this.textBox7.Multiline = true;
			this.textBox7.Name = "textBox7";
			this.textBox7.ReadOnly = true;
			this.textBox7.Size = new System.Drawing.Size(376, 163);
			this.textBox7.TabIndex = 1;
			this.textBox7.Text = resources.GetString("textBox7.Text");
			this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
			this.label7.Location = new System.Drawing.Point(29, 31);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(376, 21);
			this.label7.TabIndex = 0;
			this.label7.Text = "Generador de Reglas usando LM-Regla";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1FileOk);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.SteelBlue;
			this.ClientSize = new System.Drawing.Size(463, 354);
			this.Controls.Add(this.tabControl1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.Text = "Generador LM Regla";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.tabPage4.ResumeLayout(false);
			this.tabPage4.PerformLayout();
			this.tabPage5.ResumeLayout(false);
			this.tabPage5.PerformLayout();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.ListBox listBox3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl tabControl1;
		
		void TabControl1Selected(object sender, System.Windows.Forms.TabControlEventArgs e)
		{
			listBox2.Items.Clear();
			listBox3.Items.Clear();
			foreach(string atomoo in listBox1.Items){
				listBox2.Items.Add(atomoo);
				listBox3.Items.Add(atomoo);				
			}
			Button8Click(null,null);
			Button10Click(null,null);
		}
		
		void Button8Click(object sender, System.EventArgs e)
		{
			PolacaInv pi=new PolacaInv(textBox2.Text);
			textBox3.Text=pi.hazPolacaInv();
		}
		
		void CheckBox2CheckedChanged(object sender, System.EventArgs e)
		{
			negadoConc=!negadoConc;
		}
		
		void Button9Click(object sender, System.EventArgs e)
		{   
			string opr="";
			if (!textBox4.Text.Equals("")) opr="& ";
			textBox4.Text=textBox4.Text+opr+(objetivo?"* ":"")+(negadoConc?"� ":"")+listBox2.SelectedItem+" ";
		}
		
		void Button10Click(object sender, System.EventArgs e)
		{
			PolacaInv pi=new PolacaInv(textBox4.Text);
			textBox5.Text=pi.hazPolacaInv();
		}
		
		void Button11Click(object sender, System.EventArgs e)
		{
			string [] partesCond=textBox3.Text.Split(new char [] {' '});
			string [] partesConc=textBox5.Text.Split(new char [] {' '});
			bool obj=false;
			textBox6.Text="<regla> <condicion> ";			
			foreach(string parteCond in partesCond){
				switch(parteCond){
					case "�":textBox6.Text+="<negacion/> ";
						     break;
				    case "&":textBox6.Text+="<conjuncion/> ";
						     break;
				    case "|":textBox6.Text+="<disyuncion/> ";
						     break;				    
				    default:if (!parteCond.Equals(""))
				    	     textBox6.Text+="<atomo> "+parteCond+" </atomo> ";
						    break;
				}
			}
			textBox6.Text+="</condicion> <conclusion> ";
			foreach(string parteConc in partesConc){
				switch(parteConc){
					case "�":textBox6.Text+="<negacion/> ";
						     break;
				    case "&":textBox6.Text+="<conjuncion/> ";
						     break;
					case "*":obj=true;
				             break;
				    default:if (!parteConc.Equals("")){
						    if (obj){
							 textBox6.Text+="<atomoObj> "+parteConc+" </atomoObj> ";
							 obj=false;
							}else{
						     textBox6.Text+="<atomo> "+parteConc+" </atomo> ";
				            }}
						    break;
				}
			}
			textBox6.Text+="</conclusion> </regla>";
		}
		
		void Button12Click(object sender, System.EventArgs e)
		{
			openFileDialog1.InitialDirectory="." ;
            		openFileDialog1.Filter="Archivos de �tomos (*.atm)|*.atm|Todos los archivos (*.*)|*.*" ;
		       openFileDialog1.FilterIndex=1;
            		openFileDialog1.RestoreDirectory = true;
            		openFileDialog1.FileName="";
            		openFileDialog1.ShowDialog();            
		}
		
		void OpenFileDialog1FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			StreamReader flujo=null;	
			string nom=openFileDialog1.FileName;
			string cadTmp=null;
			if (!nom.Equals("")){
				try{
					flujo=new StreamReader(nom);
					do{
						cadTmp=flujo.ReadLine();
						if (cadTmp!=null&&
						    !listBox1.Items.Contains(cadTmp.ToUpper()))
						 listBox1.Items.Add(cadTmp.ToUpper());
					}while(cadTmp!=null);
				}catch(FileNotFoundException fnfe){
					System.Console.WriteLine("Archivo {0} no encontrado",nom);
					System.Console.WriteLine("Sucedio {0}",fnfe);
			 	}
			 	catch(IOException ioe){
					System.Console.WriteLine("Problema de Entrada Salida");
					System.Console.WriteLine("Sucedio {0}",ioe);
			 	}
			 	catch(System.Exception eg){
					System.Console.WriteLine("Problemas varios");
					System.Console.WriteLine("Sucedio {0}",eg);
			 	}
			}
		}
		
		void Button13Click(object sender, System.EventArgs e)
		{
			textBox2.Text="";
		}
		
		void Button14Click(object sender, System.EventArgs e)
		{
			textBox4.Text="";
		}
		
		void CheckBox3CheckedChanged(object sender, System.EventArgs e)
		{
			objetivo=!objetivo;
		}
	}
}
