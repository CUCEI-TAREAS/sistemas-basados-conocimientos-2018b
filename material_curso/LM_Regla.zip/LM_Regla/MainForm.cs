/*
* M�dulo Principal
*
* Responsable de coordinar los eventos de la aplicaci�n. 
* 
* En particular, captura los eventos realizados en la interfaz para ir produciendo
* una forma preliminar de la regla; misma que eventualmente se representar� en
* el lenguaje LM-Regla. Producto de esta misma investigaci�n sobre gesti�n y
* representaci�n de conocimiento para la construcci�n de Sistemas Expertos.
*
* <LM-Regla>::='<regla>'<condici�n_compuesta><conclusi�n_compuesta>'</regla>'
* <condici�n_compuesta>::='<condici�n>'<expresi�n_l�gica_condicional>'</condici�n>'
* <expresi�n_l�gica_condicional>::='<�tomo>'<nombre_�tomo>'</�tomo>'['<negaci�n/>']
*                                  '<�tomo>'<nombre_�tomo>'</�tomo>'['<negaci�n/>'] 
*                                  (<conjunci�n/>|<disyunci�n/>) ['<negaci�n/>']
* <conclusi�n_compuesta>::='<conclusi�n>'<expresi�n_l�gica_conclusi�n>'</conclusi�n>'
* <expresi�n_l�gica_conclusi�n>::='<�tomo>'<nombre_�tomo>'</�tomo>'['<negaci�n/>']
*                                 '<�tomo>'<nombre_�tomo>'</�tomo>'['<negaci�n/>'] 
*                                 <conjunci�n/> ['<negaci�n/>']
* <nombre_�tomo>::=<secuencia_simbolos>
* <secuencia_simbolos>::=(<letra>[<s�mbolo_v�lido>]|<letra>[<s�mbolo_v�lido>]<secuencia_simbolos>)
* <s�mbolo_v�lido>::=(<letra>|<d�gito>|-|_)
* <letra>::=(A|B|C|D|E|F|G|H|I|J|K|L|M|N|�|O|P|Q|R|S|T|U|V|W|X|Y|Z)
* <d�gito>::=(0|1|2|3|4|5|6|7|8|9)
*
* Desarrollador: Luis Alberto Casillas Santill�n
* Fecha: 11/08/2006
*
*/

using System;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;

namespace LM_Regla
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm{
		bool negado=false;
		[STAThread]
		
		public static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button1Click(object sender, System.EventArgs e)
		{
			if (!textBox1.Text.Equals("")){
				if (!listBox1.Items.Contains(textBox1.Text.ToUpper()))
					listBox1.Items.Add(textBox1.Text.ToUpper());
				else MessageBox.Show("�No duplicar �tomos!","Fallo al ingresar datos",
				                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else MessageBox.Show("�Primero capturar �tomo!","Fallo al ingresar datos",
				                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
		
		
		void Button2Click(object sender, System.EventArgs e)
		{
			textBox2.Text+=" &";
		}
		
		void Button3Click(object sender, System.EventArgs e)
		{
			textBox2.Text+=" |";
		}
		
		void Button4Click(object sender, System.EventArgs e)
		{
			textBox2.Text+=" (";
		}
		
		void Button5Click(object sender, System.EventArgs e)
		{
			textBox2.Text+=" )";
		}
		
		void Button6Click(object sender, System.EventArgs e)
		{
			textBox2.Text+=(" "+(negado?"� ":"")+listBox3.SelectedItem);
		}
		
		void Button7Click(object sender, System.EventArgs e)
		{
			ArrayList lista=new ArrayList();
			string cad=(string)listBox1.SelectedItem;
			foreach(string atomo in listBox1.Items){
				if (!atomo.Equals(cad))
					lista.Add(atomo);
			}
			listBox1.Items.Clear();
			foreach(string atomo in lista){
				listBox1.Items.Add(atomo);
			}
		}
		
		void CheckBox1CheckedChanged(object sender, System.EventArgs e)
		{
			negado=!negado;
		}
	}
}
