/*
* Polaca Inversa
*
* M�dulo responsable de la conversi�n a una representaci�n
* postfija de la expresi�n l�gica que se ha colocado en la
* porci�n de condici�n de la regla.
*
* En la construcci�n recibe la expresi�n en infijo que luego
* se convertir� a postfijo. Usa el m�todo de pilas, que se 
* apoya en las prioridades de los operadores para definir la
* colocaci�n definitiva de un operador, durante la soluci�n
* ordenada que sigue una computadora siguiendo su m�todo
* convencional de operaci�n. Igualmente elimina prioridades
* expresadas con par�ntesis. Acciones realizadas en la rutina
* hazPolacaInv()
*
* Desarrollador: Luis Albero Casillas Santill�n
* Fecha: 11/08/2006
*/

using System;

namespace LM_Regla{	
	public class PolacaInv{
		string cad;
		string [] partes,polaca;
		Pila aux,p;		
		public PolacaInv(string cad){
			this.cad=cad;
			partes=cad.Split(new Char [] {' '});
			
			aux=new Pila(partes.Length);
			p=new Pila(partes.Length);
		}
		int prioridad(string opr){
			switch(opr){
				case "�":return 3;
				case "&":return 2;
				case "|":return 1;
			}
			return 0;
		}
		internal string hazPolacaInv(){
			string tope=null;
			string reg="";
			foreach(string parte in partes){
				switch(parte){
					case "�":case "&":case "|":
						if (!aux.vacia()){
							do{
								tope=aux.top();
								if (!tope.Equals("*")){
								    if (prioridad(tope)>
								    	prioridad(parte)){
								     p.push(aux.pop());
								    }
								}else aux.pop();
							}while(!tope.Equals("*")&&
							       !tope.Equals("�")&&
							       prioridad(tope)>prioridad(parte)&&
							       !aux.vacia());
						}
						aux.push(parte);
					break;
					case "(":case ")":
						if (parte.Equals("(")){
							aux.push("*");
						}else{
							do{
								tope=aux.top();
								if (tope!=null && !tope.Equals("*"))
									p.push(aux.pop());
							}while(tope!=null&&
						           !tope.Equals("*")&&
						           !aux.vacia());
							aux.pop();
						}
						break;
					default: p.push(parte);
						break;
				}
			}
			while(!aux.vacia()){
				p.push(aux.pop());
			}
			polaca=new string[p.numElems()];
			for(int i=0;i<polaca.Length;i++){
				polaca[i]=p.datos[i];
				reg=reg+" "+polaca[i];
			}	
			return reg;
		}
	}
}
