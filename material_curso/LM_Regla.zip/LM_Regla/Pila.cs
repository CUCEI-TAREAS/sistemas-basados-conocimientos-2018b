/*
* Pila
* 
* Implementaci�n de una pila convencional, con sus respectivos operadores
* PUSH(), POP(), TOP(), VACIA(), NUMELEMS().
*
* En este proyecto, una pila permite resolver el proceso de conversi�n
* de infijo a postfijo; pues una estructura de datos PILA puede recordar
* elementos de informaci�n y mantener memoria del orden en que los elementos
* fueron ingresado, en este caso encontrados, dentro de la expresi�n.
*
* Desarrollador: Luis Alberto Casillas Santill�n
* Fecha: 11/08/2006
*
*/

using System;

namespace LM_Regla{
	public class Pila{
		internal string [] datos;
		int posTope=-1;
		internal Pila(int tam){
			datos=new string[tam];
		}
		internal bool vacia(){
			return posTope==-1;
		}
		internal void push(string e){
			datos[++posTope]=e;
		}
		internal string top(){
			if (!vacia()) return datos[posTope];
			return null;
		}
		internal string pop(){
			if (!vacia()) return datos[posTope--];
			return null;
		}
		internal int numElems(){
			return posTope+1;
		}
	}
}
