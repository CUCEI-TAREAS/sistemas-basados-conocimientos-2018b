/*
 * Lector
 * Lector genérico propio para capturar datos diversos desde el teclado...
 *
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.io.*;

public final class Lector {
 public static String lee(){
  String cad=null;
  BufferedReader ent=new BufferedReader(new InputStreamReader(System.in));
  try{
   cad=ent.readLine();
  }catch (IOException e){
    System.out.println("Falla en la entrada");
   }
  return cad;
 }
 public static int leeEnt(){
  int res=0;
  try{
   res=Integer.parseInt(lee());
  }catch (NumberFormatException e){
    System.out.println("Se esperaba entero....");
   }
  return res;
 }
 public static double leeDoble(){
  double res=0;
  try{
   res=Double.parseDouble(lee());
  }catch(NumberFormatException e){
    System.out.println("Se esperaba flotante....");
   }
  return res;
 }
 public static char leeCar(){
  String cad=lee();
  if (cad!=null&&cad.length()>0) return cad.charAt(0);
  return '\0';
 }    
}
