/*
 * AtomoDuplicado
 * 
 * Es una clase auxiliar que representa la excepción 
 * específica de que un átomo ha sido duplicado al 
 * interior de una regla: en su condición compuesta o 
 * conclusión múltiple, o bien en la memoria de trabajo
 * del propio sistema basado en conocimiento.
 * 
 * Al ser lanzada esta excepción, acciona los mecanismos
 * de respuesta al suceso de duplicación de átomo en los
 * receptáculos diseñados para ello.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

public class AtomoDuplicado extends Exception{
    AtomoDuplicado(String desc){
        super("Atomo Duplicado: "+desc);
    }    
}
