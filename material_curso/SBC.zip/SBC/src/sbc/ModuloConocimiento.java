/*
 * ModuloConocimiento
 * 
 * Clase esencial de este entorno genérico para sistemas
 * basados en conocimiento. Es la responsable de contener y
 * basado en conocimiento.
 * 
 * Específicamente contiene la ontología que el experto
 * artificial debe procesar, por medio de una base de
 * conocimiento que contiene todas las reglas expresadas
 * originalmente en LM-Regla y luego en una codificación
 * interna congruente al resto de este modelo.
 * 
 * Responsable de cargar la base de conocimiento, apoyándose
 * en el comportamiento implementado en la clase Regla. 
 * Filtra las reglas que concluyen objetivos, elimina las 
 * marcas de disparo y las marcas para encadenamiento hacia
 * atrás hechas durante este tipo de inferencia.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class ModuloConocimiento {
    String desc;
    ArrayList bc;
    ModuloConocimiento(String desc){
	this.desc=desc;
    }
    ModuloConocimiento(String desc,String archBC){
	this.desc=desc;
        bc=new ArrayList();
	cargarBC(archBC);
    }
    void cargarBC(String nomArch){
	LeeArch la=new LeeArch(nomArch);
	String reglaCad=null;
	while((reglaCad=la.lee())!=null){
            reglaCad=reglaCad.toLowerCase();
            if (!reglaCad.equals("<bc>") &&
                !reglaCad.equals("</bc>") &&
                !reglaCad.equals("")){
                //System.out.println("Cargando Regla: "+reglaCad);
                bc.add(new Regla(reglaCad));
            }
	}
	la.cierra();
    }
    @Override
    public String toString(){
	String retorno="Modulo de Conocimiento: "+desc+"\n";
	for(Object elemento : bc){
            retorno+=(elemento+"\n");
	}
	return retorno;
    }
    ArrayList filtrarObjs(){
	ArrayList objs=new ArrayList();
	Regla r=null;
	for(Object elemento : bc){
            r=(Regla)elemento;
            if (r.esObjetivo()) objs.add(r);
	}
        System.out.println(objs.size()+" objetivos encontrados en la BC...");
	return objs;
    }
    void desmarcar(){
	Regla r=null;
	for(Object elemento : bc){
            r=(Regla)elemento;
            r.marca=false;
	}
    }
    void quitarDisparos(){
	Regla r=null;
	for(Object elemento : bc){
            r=(Regla)elemento;
            r.disparo=false;
	}
    }
}
