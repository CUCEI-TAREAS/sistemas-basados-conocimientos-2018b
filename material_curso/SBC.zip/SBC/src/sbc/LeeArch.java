/*
* LeeArch
 * 
 * Clase auxiliar responsable de recuperar información
 * contenida en un archivo específico. 
 * 
 * En particular, el módulo de conocimiento de este
 * gestor genérico para sistema basado en conocimiento se apoya en los
 * servicios de esta clase para recuperar la base de
 * conocimiento del sistema de archivos.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.io.*;

public class LeeArch {
    File arch = null;
    BufferedReader ent = null;
    LeeArch(String nom){
        try{
	 arch = new File(nom);
	 ent = new BufferedReader(new FileReader(arch));
	}catch(IOException e){
            e.printStackTrace();
        }
    }
    void cierra(){
        try{
            ent.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    String lee(){
        try{
            return ent.readLine();
        }catch(IOException e){
            e.printStackTrace();
        }
        return null;
    }
}
