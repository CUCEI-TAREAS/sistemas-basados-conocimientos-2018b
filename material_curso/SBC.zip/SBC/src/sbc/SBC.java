/* 
 * SBC
 *
 * Esta clase es el orquestador principal del desempeño
 * de este sistema basado en conocimiento.
 * 
 * Desde este punto se crean las instancias concretas
 * de los elementos principales del sistema basado en conocimiento: 
 * Motor de Inferencia, Módulo de Conocimiento y
 * Memoria de Trabajo.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class SBC {    
    MemoriaTrabajo mt=new MemoriaTrabajo();
    // Al construir el módulo de conocimiento se
    // indica por medio de sus parámetros cuál
    // es el nombre de la ontología con que se
    // trabajará y el nombre del archivo donde se
    // encuentra almacenada la base de conocimiento.
    // En este caso el nombre es Animales, y se encuentra
    // en el archivo Zoo.bc.
    ModuloConocimiento mc=new ModuloConocimiento("Zoo","zoo.xml");
    MotorInferencia mi=new MotorInferencia();
    public static void main(String[] args){        
	ArrayList res=null;
	SBC se=new SBC();
	System.out.println("SBC Java 2018");		
	System.out.println(se.mc);
	// Aquí podrían inyectarse átomos
	// a mt, antes de hacer la inferencia...
	res=se.mi.encadenarAdelante(se.mc,se.mt);
        System.out.println("************************************************");
	if (res!=null){
            System.out.print("Exito: ");
            for(Object a : res){
		System.out.print(a+" ");
            }
            System.out.println(se.mt);
	}
	else System.out.println("Fracaso...");
	//System.out.println(se.mc);	
    }
}

