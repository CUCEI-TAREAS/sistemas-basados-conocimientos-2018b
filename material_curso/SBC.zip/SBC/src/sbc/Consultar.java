/*
 * Consultar
 * 
 * Clase auxiliar responsable de consultar al usuario del
 * entorno genérico de sistema basado en conocimiento acerca del 
 * cumplimiento de diferentes hechos que podrían darse en
 * el caso de la realidad que se verifica.
 * 
 * De acuerdo al funcionamiento convencional de un sistema
 * experto, se deben tomar hechos de la realidad y luego 
 * confrontarlos con el conocimiento almacenado en la ontología
 * o base de conocimientos; el resultado es información útil,
 * normalmente conocida como la meta del sistema basado
 * en conocimiento.
 * 
 * Datos ---> SBC---> Información
 *             ^
 *             |
 *        Conocimiento
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

public class Consultar {
    static boolean porAtomo(Atomo aa,Regla ra){
	String resp;
	do{
            System.out.print("Se cumple "+aa.desc+"? (S/N/P): ");
            resp=Lector.lee();
            resp=resp.toUpperCase();
            //System.out.println();
            if (resp.equals("P")){
		System.out.println("Se intenta probar que: "+ra);
            }
	}while(!resp.equals("S")&&!resp.equals("N"));
            return resp.equals("S");
    }
}
