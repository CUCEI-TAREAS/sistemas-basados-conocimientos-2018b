/*
 * Atomo
 * 
 * La clase átomo es esencial para este entorno genérico 
 * para sistemas basados en conocimiento. Representa elementos concretos
 * de la realidad que busca ser procesada a través de un
 * experto artificial modelado al interior del presente
 * entorno.
 * 
 * Esta clase incluye diversos atributos y operadores, a 
 * partir de los cuales logra el tratamiento adecuado de la
 * porción mínima de realidad a tratar, un átomo. Elemento
 * simbólico de la programación declarativa, útil en la
 * confección de una ontología.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

public class Atomo extends ParteRegla{
    String desc;
    boolean estado;
    boolean objetivo;
    public Atomo(String desc,boolean estado,boolean objetivo){
        this.desc=desc.toLowerCase();
	this.estado=estado&&true;
	this.objetivo=objetivo&&true;
    }
    public Atomo(Atomo otro){
	desc=otro.desc+"";
	estado=otro.estado&&true;
	objetivo=otro.objetivo&&true;
    }
    @Override
    public String toString(){
        return (estado?"":"!")+(objetivo?"*":"")+desc;
    }
    @Override
    public boolean equals(Object obj){
	Atomo aTmp=(Atomo)obj;
	return desc.equals(aTmp.desc)&&(estado==aTmp.estado);			
    }
    boolean verIgualdad(Atomo aTmp){
        return desc.equals(aTmp.desc)/*&&(estado==aTmp.estado)*/;
    }
    boolean verVerdad(Atomo aTmp){
        if (aTmp==null) return false;
        return estado&&aTmp.estado;
    }
}
