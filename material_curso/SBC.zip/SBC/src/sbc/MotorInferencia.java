/*
 * MotorInferencia
 * 
 * El motor de inferencia es una clase esencial para este gestor
 * genérico de sistemas basados en conocimiento. Eje de la inferencia y del 
 * proceso de confrontación de datos (almacenados en la memoria
 * de trabajo) con el conocimiento ontológico almacenado en la base 
 * de conocimiento, para producir el resultado meta.
 * 
 * Específicamente este motor de inferencia cuenta con los
 * operadores responsables de realizar encadenamiento hacia 
 * adelante (modus ponens) y hacia atrás (modus ponens invertido), 
 * así como los operadores auxiliares para cumplir estas tareas:
 * concatenar y esElegible.
 * 
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class MotorInferencia {
    boolean backward=false;
    ArrayList encadenarAdelante(ModuloConocimiento mc,
		                MemoriaTrabajo mt){
	Regla ra=null;
	Atomo aa=null;
	boolean resConsulta=false;
	boolean resCondicion=false;
        for(Object elemento : mc.bc){
            ra=(Regla)elemento;
            for(Object elemCond : ra.partesCond){
		if (elemCond instanceof Atomo){
                    aa=(Atomo)elemCond;
                    aa=new Atomo(aa.desc,aa.estado,aa.objetivo);
                    if (!mt.presente(aa)){							
			resConsulta=Consultar.porAtomo(aa,ra);
			// Verificación de certidumbre: [0,1] elem R			
			aa.estado=resConsulta;							
			try{
                            //System.out.println("Guardando "+aa);
                            // El átomo clonado debería llevar 
                            // la certidumbre.
                            mt.guardaAtomo(new Atomo(aa));
                            System.out.println("MT "+mt);
			}catch(AtomoDuplicado ad){
                            System.out.println("Se duplico el atomo: "+aa);
                            // Hacer nada...								
			}
                    }
                }
            }
            resCondicion=ra.probarCondicion(mt);
            if (resCondicion){
		System.out.println("Se disparo: "+ra);
		// Antes de llamar a ra.dispara(mt)
		// calcular certidumbre del resultado.
		// Debería enviarse como otro parámetro.
		ra.dispara(mt);
		//System.out.println(mt);
		resCondicion=false;
		if (ra.esObjetivo()) return ra.partesConc;
            }
            else{
		// Este es uno de los interruptores del SE
		// Si se comenta, el experto consulta toda
		// la BC' aunque una regla falle.
		if (backward) return null;
		System.out.println("No se disparó...");
		// Si la condicion no se cumple, se almacenan
		// los atomos de la conclusion negados
		// esta seccion es opcional y debatible.
		// Esta sección sólo funciona si la línea: if (backward) return null;
		// está comentada...
		/*Atomo ac=null;
		ArrayList atomos=new ArrayList();
		for(Object pc : ra.partesConc){
                    if (pc instanceof Atomo){
			atomos.Add(ac=new Atomo((Atomo)pc));
                    }
                    if (pc instanceof Negacion){
			ac.estado=!ac.estado;
                    }
		}
		System.out.println("Hay {0} atomos...",atomos.Count);
		for(int i=0;i<atomos.Count;i++){						
                    System.out.println("Por negar: ",atomos[i]);
                    ac=new Atomo((Atomo)atomos[i]);
                    ac.estado=!ac.estado;
                    System.out.println("Negado: ",ac.Desc);
                    try{
			mt.guardaAtomo(ac);
			System.out.println("Guardado: ",ac);
                    }catch(AtomoDuplicado ad){
                        System.out.println("Se duplico el atomo: {0}",ac);
			// Hacer nada...
                    }
						
		} */
            }
	}
	return null;
    }
		
    private void concatena(ArrayList destino,ArrayList fuente){
	Atomo aTmp=null;
	//Negacion nTmp=null;
	for(Object aAgregar : fuente){
            if (aAgregar instanceof Atomo){
		aTmp=new Atomo((Atomo)aAgregar);
		destino.add(aTmp);
            }
            if (aAgregar instanceof Negacion)
                aTmp.estado=!aTmp.estado;
	}
    }
		
    private boolean esElegible(Regla r,ArrayList porSatisfacer){
	ArrayList atomosConc=new ArrayList();
	Atomo aTmp=null;
	for(Object aa : r.partesConc){
            if (aa instanceof Atomo){
		aTmp=new Atomo((Atomo)aa);
		atomosConc.add(aTmp);
            }
            if (aa instanceof Negacion) aTmp.estado=!aTmp.estado;
	}
	for(Object aa : atomosConc){
            if (porSatisfacer.contains(aa)) return true;
	}
	return false;
    }
		
    ArrayList encadenarAtras(ModuloConocimiento mc,
		             MemoriaTrabajo mt){
	ArrayList reglasObj=mc.filtrarObjs();
	ArrayList aSatisfacer=new ArrayList();
	ArrayList bcPrima=new ArrayList();
	ArrayList resultado=null;
	String nomBCPrima=null;
        Regla ra=null;
	boolean [] usadas=new boolean[reglasObj.size()];
	boolean salir=false;
	int pos=-1,veces=0,total=reglasObj.size();
	backward=true;
	ModuloConocimiento mcTmp=null;
	do{
            pos=(int)(Math.random()*total); //En lugar de esto, podría ir un
				            //heurístico que elija un objetivo
				            //con base en la evaluación del 
				            //contexto situacional.
            if (!usadas[pos]){					
		veces++;
		usadas[pos]=true;
		aSatisfacer.clear();
		bcPrima.clear();
		mc.desmarcar();
		mc.quitarDisparos();
		for(Object pConc : ((Regla)reglasObj.get(pos)).partesConc){
                    if (pConc instanceof Atomo){
			Atomo aObj=(Atomo)pConc;
			if (aObj.objetivo){
                            nomBCPrima=aObj.desc.toUpperCase();
			}
                    }
		}
		mcTmp=new ModuloConocimiento(nomBCPrima);
		// Bootstrap!!!
		concatena(aSatisfacer,((Regla)reglasObj.get(pos)).partesConc);
		do{
                    salir=true;
                    for(Object elem : mc.bc){
                        ra=(Regla)elem;
			if (!ra.marca&&esElegible(ra,aSatisfacer)){
                            salir=false;
                            System.out.println("Elegida: "+ra);
                            ra.marca=true;
                            concatena(aSatisfacer,ra.partesCond);
                            bcPrima.add(0,ra);
			}
                    }
		}while(!salir);
		mcTmp.bc=bcPrima;
		System.out.println("\nIntentando con: "+mcTmp+"\n");				
		resultado=encadenarAdelante(mcTmp,mt);
		if (resultado!=null){
                    backward=false;
                    return resultado;
		}
            }
	}while(veces<total);
	backward=false;
	return null;
    }
}
