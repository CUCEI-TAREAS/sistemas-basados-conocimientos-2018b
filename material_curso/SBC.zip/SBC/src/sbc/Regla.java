/*
 * Regla
 * 
 * La clase regla es esencial para este entorno genérico de 
 * sistemas basados en conocimiento. Representa una expresión
 * del conocimiento en una codificación SI-ENTONCES por medio
 * del lenguaje LM-Regla. 
 * 
 * Responsable de codificar y descodificar el conocimiento 
 * que debe gestionar, puede evaluar y disparar a partir del
 * conocimiento en la memoria de trabajo. Del mismo modo, al
 * disparar ingresa a la memoria de trabajo los elementos 
 * de la conclusión múltiple que debe gestionar, y en el 
 * caso de haber alcanzado un objetivo definitivo del sistema
 * experto lo notifica adecuadamente.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class Regla {
    ArrayList partesCond=new ArrayList();		
    ArrayList partesConc=new ArrayList();
    boolean marca=false;
    boolean disparo=false;
    boolean objetivo=false;
    public Regla(String reglaCad){
        analiza(reglaCad);
    }
    @Override
    public String toString(){
        String retorno="SI ";
        for(Object elemCond : partesCond){
            retorno+=(elemCond+" ");
        }
	retorno+="ENTONCES ";
	for(Object elemConc : partesConc){
            retorno+=(elemConc+" ");
        }
	return retorno;
    }
    boolean probarCondicion(MemoriaTrabajo mt){
        PilaBooleana pb=new PilaBooleana();
        boolean verdad1=false,verdad2=false;
        Atomo aTmp=null,aMT=null;
        Negacion nTmp=null;
        Conjuncion cTmp=null;
        Disyuncion dTmp=null;
        for(Object elemCond : partesCond){				
            if (elemCond instanceof Atomo){
                aTmp=(Atomo)elemCond;
                aMT=mt.recupera(aTmp);
		verdad1=aTmp.verVerdad(aMT);
		pb.push(verdad1);
            } else 
            if (elemCond instanceof Negacion){
                nTmp=(Negacion)elemCond;
                verdad1=pb.pop();
                verdad1=!verdad1;
                pb.push(verdad1);
            } else
            if (elemCond instanceof Conjuncion){
                cTmp=(Conjuncion)elemCond;
                verdad1=pb.pop();
                verdad2=pb.pop();
                pb.push(verdad1&&verdad2);
            } else
            if (elemCond instanceof Disyuncion){
                dTmp=(Disyuncion)elemCond;
                verdad1=pb.pop();
                verdad2=pb.pop();
                pb.push(verdad1||verdad2);
            }
        }
	return pb.pop();
    }
    boolean dispara(MemoriaTrabajo mt){
        Atomo aTmp=null;
        boolean llegoObj=false;
        disparo=true;
	ArrayList atomos=new ArrayList();
	for(Object elemConc : partesConc){
            // El nivel de certidumbre que se reciba
            // se asigna a los átomos conclusión
            // que se ingresarán a la MT.
            if (elemConc instanceof Atomo){
                    aTmp=new Atomo((Atomo)elemConc);		
                    atomos.add(aTmp);
                    if (aTmp.objetivo) llegoObj=true;
            } else
            if (elemConc instanceof Negacion){
                    aTmp.estado=!aTmp.estado;					
            }				
        }
        for(Object aa : atomos){
            try{
                    mt.guardaAtomo((Atomo)aa);
            }catch(AtomoDuplicado ad){
                    System.out.println("Se duplico el atomo: "+aa);
                    // Hacer nada...
            }
        }
        return llegoObj;
    }
    boolean esObjetivo(){
            return objetivo;
    }
    void analiza(String r){
        String [] partes=r.split(" ");
        boolean cond,conc,atomo,obj;
        ParteRegla pr=null;
        cond=conc=atomo=obj=false;
        //System.out.println(r);
        for(String parte : partes){
            //System.out.println(parte);
            switch(parte){
                    // Etiquetas Dobles //
                    case "<atomo>": atomo=true;
                                    obj=false;
                                    break;
                    // ---------------------------------			         
                    case "</atomo>": atomo=false;
                                     obj=false;
                                     break;
                    // ---------------------------------				     
                    case "<atomoobj>": atomo=true;
                                       obj=true;
                                       objetivo=true;
                                       break;
                    // ---------------------------------			         
                    case "</atomoobj>": atomo=false;
                                        obj=false;
                                        break;
                    // ---------------------------------				     
                    case "<condicion>": cond=true;
                                        break;
                    // ---------------------------------			         
                    case "</condicion>": cond=false;
                                         break;
                    // ---------------------------------			         
                    case "<conclusion>": conc=true;
                                         break;
                    // ---------------------------------			         
                    case "</conclusion>": conc=false;
                                          break;
                    // Etiquetas Sencillas //
                    case "<negacion/>": pr=new Negacion();
                                        if (cond&&!conc) partesCond.add(pr);
                                        if (conc&&!cond) partesConc.add(pr);
                                        break;
                    // ---------------------------------				     
                    case "<conjuncion/>": pr=new Conjuncion();
                                          if (cond&&!conc) partesCond.add(pr);
                                          if (conc&&!cond) partesConc.add(pr);
                                          break;
                    // ---------------------------------				     
                    case "<disyuncion/>": pr=new Disyuncion();
                                          if (cond&&!conc) partesCond.add(pr);
                                          //if (conc&&!cond) partesConc.add(pr);
                                          break;
                    // ---------------------------------				     
                    default: if (atomo){
                              pr=new Atomo(parte,true,obj);
                              if (cond&&!conc&&!obj) partesCond.add(pr);
                              if (conc&&!cond) partesConc.add(pr);
                             }
                             break;
                }
        }
    }
}

