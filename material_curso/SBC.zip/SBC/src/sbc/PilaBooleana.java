/*
 * PilaBooleana
 * 
 * Clase auxiliar, responsable de administrar una pila
 * con una representación de datos específica para el 
 * enfoque de este entorno genérico para sistemas basados 
 * en conocimiento.
 * 
 * En particular, es utilizada para realizar la evaluación
 * lógica de las condiciones compuestas, contenidas en las
 * representaciones LM-Regla; que se encuentran expresadas
 * en notación postfija libre de complejidad en paréntesis
 * y presedencias, y directamente procesable por la maquinaria
 * computacional.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class PilaBooleana{
    ArrayList datos;
    PilaBooleana(){
        datos=new ArrayList();
    }
    void anula(){
        datos.clear();
    }
    boolean vacia(){
        return datos.isEmpty();
    }
    boolean top(){
        if (!vacia()){
            return (boolean)datos.get(datos.size()-1);
        }
        return false;
    }
    boolean pop(){
        boolean tmp;
        if (!vacia()){
                tmp=(boolean)datos.get(datos.size()-1);
                datos.remove(datos.size()-1);
                return tmp;
        }
        return false;
    }
    void push(boolean valor){
        datos.add(valor);
    }
}
