/*
 * ParteRegla
 * 
 * Clase auxiliar responsable de representar a un 
 * elemento neutro al interior de una regla. Esta clase
 * es una generalización de los diferentes elementos
 * contenidos en una regla, tales como átomos y operadores.
 * 
 * La creación de una clase de esta naturaleza facilita el 
 * tratamiento polimorfo de las piezas que constituyen una
 * regla, por esta razón carece de atributos y rutinas dentro.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

public class ParteRegla {}
