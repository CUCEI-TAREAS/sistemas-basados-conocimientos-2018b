/*
 * Conjuncion
 * 
 * Clase auxiliar que representa al operador lógico Conjunción
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

public class Conjuncion extends Operador{
    @Override
    public String toString(){
        return "&";
    }    
}
