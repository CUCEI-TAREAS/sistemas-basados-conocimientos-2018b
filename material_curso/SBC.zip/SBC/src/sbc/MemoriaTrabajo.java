/*
 * MemoriaTrabajo
 * 
 * Clase esencial de este entorno genérico para sistemas
 * basados en conocimiento. Responsable de contener los datos
 * concretos del caso de la realidad que actualmente procesa este
 * sistema basado en conocimiento.
 * 
 * En particular, cuando el sistema basado en conocimiento está
 * verificando diferentes hechos de la realidad; almacena en esta 
 * estructura los átomos que se han cotejado por medio de un
 * simple interrogatorio, o bien cuando una regla se dispara
 * y los átomos contenidos en su conclusión se almacenan.
 * 
 * Es capaz de controlar los átomos que se han afirmado y 
 * negado en el proceso, con el fin de lograr un tratamiento
 * preciso de la lógica modelada en la ontología del sistema
 * experto.
 * 
 * Desarrollador: Dr. Luis Alberto Casillas Santillán
 * Fecha: 18-Dic-2017
 */

package sbc;

import java.util.ArrayList;

public class MemoriaTrabajo {
    ArrayList afirmados;
    ArrayList negados;
    MemoriaTrabajo(){
            afirmados=new ArrayList();
            negados=new ArrayList();
    }
    void guardaAtomo(Atomo aa) throws AtomoDuplicado{
        if (!afirmados.contains (aa)&&!negados.contains (aa)){
                if (aa.estado) afirmados.add(aa);
                else negados.add(aa);
        }else{
                throw new AtomoDuplicado(aa.desc);
        }
    }
    boolean presente(Atomo aa){
        Atomo aTmp=new Atomo(aa);
        aTmp.estado=!aTmp.estado;
        return (afirmados.contains (aa)||negados.contains (aa)||
                afirmados.contains (aTmp)||negados.contains (aTmp));
    }
    boolean fueAfirmado(Atomo aa){
            return afirmados.contains (aa);
    }
    boolean fueNegado(Atomo aa){
            return negados.contains(aa);
    }
    Atomo recupera(Atomo aa){
            int pa=afirmados.indexOf(aa);
            int pn=negados.indexOf(aa);
            if (pa>-1) return (Atomo)afirmados.get(pa);
            if (pn>-1) return (Atomo)negados.get(pn);
            return null;
    }
    @Override
    public String toString(){
            String retorno="\nMemoria de Trabajo\nAfirmados: [ ";
            for(Object a : afirmados) retorno+=(a+" ");
            retorno+="]\nNegados: [ ";
            for(Object a : negados) retorno+=(a+" ");
            retorno+="]";
            return retorno;
    } 
}
